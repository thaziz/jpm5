<html>
  <head>
     
 


    <style type="text/css">

    .text-center{
      text-align:center;
    }


    </style>

  </head>

  <body>
      <div class="text-center">
        <h2>    <b>     <u>SURAT KETERANGAN </u> </b> </h2>
             Nomor : 066 / PT-AWKB / VI / 2017 </div>
      <br>
    
      <p>
        Saya yang bertanda tangan dibawah ini : </p>
      
          <table border="0">
            <tr>
              <td width="20"> </td>
              <td width="50"> Nama</td>
              <td width="10"> :</td>
              <td width="200"> <b> ABSARITA YUNAIRI A, SPi </b></td>
            </tr>

            <tr>
              <td width="20"> </td>
              <td width="50"> Jabatan</td>
              <td width="10"> :</td>
              <td width="200">Manager HRD</td>
            </tr>

            <tr>
              <td width="20"> </td>
              <td width="50"> Alamat </td>
              <td width="10"> :</td>
              <td width="200"> Jl. Raya Bypass KM 31 Krian - Kab. Sidoarjo</td>
            </tr>

            <tr>
              <td colspan="4">
              </td>
            </tr>

            <tr>
              <td colspan="4">
                Menerangkan bahwa
              </td>
            </tr>

            <tr>
              <td colspan="4">
              </td>
            </tr>

             <tr>
              <td width="20"> </td>
              <td width="50"> Nama</td>
              <td width="10"> :</td>
              <td width="200"> <b> SIYADI </b></td>
            </tr>

            <tr>
              <td width="20"> </td>
              <td width="50"> Jabatan</td>
              <td width="10"> :</td>
              <td width="200">QC</td>
            </tr>

            <tr>
              <td width="20"> </td>
              <td width="50"> Alamat</td>
              <td width="10"> :</td>
              <td width="200">Ds Rowogempul RT/RW 06/08 Kec Lekok Kab Pasuruan</td>
            </tr>

          </table>
        <br>
        <br>
    Adalah Pekerja PT PERWITA NUSARAYA MJI yang dipekerjakan di PT KARUNIA ALAM SEGAR GRESIK terhitung mulai bekerja pada tanggal 1 April 2016 sampai dengan 2 Agustus 2016, yang mana Pekerja tersebut di atas sudah non aktif dan tidak terdaftar sebagai peserta BPJS Kesehatan di perusahaan kami

       <br>
       <br>
      Demikian Surat Keterangan ini diberikan untuk dapat dipergunakan sebagaimana mestinya.

       <br>
       <br>
       <br>
       <br>
    

      Sidoarjo, 28 April 2016
       <br>
       Manager HRD
       <br>
       <br>
       <br>
       <br>
      
      Absarita Y A, Spi
  </body>
</html>

 