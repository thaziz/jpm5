<html>
  <head>
     
 


    <style type="text/css">

    .text-center{
      text-align:center;
    }


    </style>

  </head>

  <body>
      <div class="text-center">
        <h2>    <b>     <u>SURAT KETERANGAN </u> </b> </h2>
             Nomor : 066 / PT-AWKB / VI / 2017 </div>
      <br>
    
      <p>
      Manager HRD PT PERWITA NUSARAYA MJI menerangkan dengan sebenarnya : </p>
      
          <table border="0">
            <tr>
              <td width="20"> </td>
              <td width="50"> Nama</td>
              <td width="10"> :</td>
              <td width="200"> <b>PRIBADI NATA BUANA </b></td>
            </tr>

            <tr>
              <td width="20"> </td>
              <td width="50"> Tempat, Tanggal Lahir </td>
              <td width="10"> :</td>
              <td width="200"> Malang, 24 Juli 1988</td>
            </tr>

            <tr>
              <td width="20"> </td>
              <td width="50"> Alamat </td>
              <td width="10"> :</td>
              <td width="200"> Dsn Krajan RT/RW 02/01 Ds Tamankuncaran Kec Tirtoyudo Kab Malang</td>
            </tr>

            

          </table>
        <br>
        <br>
     Adalah Pekerja borong PT PERWITA NUSARAYA MJI yang ditempatkan PT MASPION Unit I Divisi ALUMINDO SHEET terhitung mulai bekerja tanggal 24 November 2010 dan sampai dengan saat ini masih berstatus sebagai karyawan PT Perwita Nusaraya MJI.

       <br>
       <br>
     Demikian Surat Keterangan Kerja ini diberikan untuk dapat dipergunakan sebagai penganjuan Kredit Kepemilikan Rumah (KPR) di Bank.

       <br>
       <br>
       <br>
       <br>
       <br>
       <br>
       <br>
       <br>

       Sidoarjo, 30 Mei 2017
       <br>
      PT PERWITA NUSARAYA MJI
       <br>
       <br>
       <br>
       <br>
      
      <u>Absarita Y A, SP.i </u> <br>
      Manager HRD

  </body>
</html>

 