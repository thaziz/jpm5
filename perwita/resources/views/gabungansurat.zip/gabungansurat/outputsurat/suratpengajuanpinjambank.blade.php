<html>
  <head>
     
 


    <style type="text/css">

    .text-center{
      text-align:center;
    }


    </style>

  </head>

  <body>
      <div class="text-center">
        <h2>    <b>     <u>SURAT KETERANGAN </u> </b> </h2>
             Nomor : 066 / PT-AWKB / VI / 2017 </div>
      <br>
    
      <p>
        Manajer HRD PT PERWITA NUSARAYA MJI menerangkan dengan sebenarnya : </p>
      
          <table border="0">
            <tr>
              <td width="20"> </td>
              <td width="50"> Nama</td>
              <td width="10"> :</td>
              <td width="200"> <b>FIKI HARTANTO </b></td>
            </tr>

            <tr>
              <td width="20"> </td>
              <td width="50"> Tempat, Tanggal Lahir</td>
              <td width="10"> :</td>
              <td width="200"> Jombang, 2 Desember 1995</td>
            </tr>

            <tr>
              <td width="20"> </td>
              <td width="50"> Alamat </td>
              <td width="10"> :</td>
              <td width="200"> Kedunglumpang RT/RW 02/01 Ds Kedunglumpang Kec Mojoagung Kab Jombang</td>
            </tr>

          </table>
        <br>
        <br>
   Adalah Pekerja borong PT PERWITA NUSARAYA MJI yang ditempatkan di  PT MASPION UNIT I Divisi SATPAM terhitung mulai bekerja pada tanggal 12 April 2010 sampai dengan diterbitkannya surat ini.

       <br>
       <br>
       Demikian Surat Keterangan ini diberikan untuk dapat dipergunakan sebagai pengajuan pinjaman di Bank BNP .



       <br>
       <br>
       <br>
       <br>
       <br>
       <br>
       <br>
       <br>

       Sidoarjo, 12 Juni 2017
       <br>
       Manager HRD
       <br>
       <br>
       <br>
       <br>
      
       Absarita Y A, SP.i
  </body>
</html>

 