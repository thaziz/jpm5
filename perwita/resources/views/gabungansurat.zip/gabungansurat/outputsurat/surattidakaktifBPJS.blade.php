<html>
  <head>
     
 


    <style type="text/css">

    .text-center{
      text-align:center;
    }


    </style>

  </head>

  <body>
      <div class="text-center">
        <h2>    <b>     <u>SURAT KETERANGAN </u> </b> </h2>
             Nomor : 066 / PT-AWKB / VI / 2017 </div>
      <br>
    
      <p>
       Saya yang bertandatangan di bawah ini : </p>
      
          <table border="0">
            <tr>
              <td width="20"> </td>
              <td width="50"> Nama</td>
              <td width="10"> :</td>
              <td width="200"> <b>ABSARITA YA, SPi </b></td>
            </tr>

            <tr>
              <td width="20"> </td>
              <td width="50"> Jabatan </td>
              <td width="10"> :</td>
              <td width="200"> Manajer HRD</td>
            </tr>

            <tr>
              <td width="20"> </td>
              <td width="50"> Alamat </td>
              <td width="10"> :</td>
              <td width="200"> Jl. Raya Bypass KM 31 Krian - Kab. Sidoarjo</td>
            </tr>

            <tr>
            <td colspan="4"> Menerangkan bahwa : </td>
            </tr>

            <tr>
              <td width="20"> </td>
              <td width="50"> Nama </td>
              <td width="10"> :</td>
              <td width="200"> <b> NOOR FAJRI</b> </td>
            </tr>

             <tr>
              <td width="20"> </td>
              <td width="50"> Jabatan </td>
              <td width="10"> :</td>
              <td width="200"> <b> Pekerja Borong</b> </td>
            </tr>

            <tr>
              <td width="20"> </td>
              <td width="50"> Jabatan </td>
              <td width="10"> :</td>
              <td width="200"> <b> Ds Tambakrejo I Duduk Sampeyan, Gresik </b> </td>
            </tr>

          </table>
        <br>
        <br>
      Adalah Pekerja PT AMERTA WIDIYA KARYA BHAKTI yang dipekerjakan di PT KARUNIA ALAM SEGAR GRESIK terhitung mulai bekerja pada tanggal 1 Agustus 2015 sampai dengan 2 November 2016, yang mana pekerja tersebut diatas sudah non aktif dan tidak terdaftar sebagai peserta BPJS kesehatan di perusahaan kami.

       <br>
       <br>
      Demikian Surat Keterangan ini diberikan untuk dapat dpergunakan sebagai persyaratan untuk mendapatkan Santunan Kematian dari BPJS Ketenagakerjaan.

       <br>
       <br>
       <br>
       <br>
       <br>
       <br>
       <br>
       <br>

       Sidoarjo, 21 Februari 2017
       <br>
       Ass Manager Personalia
       <br>
       <br>
       <br>
       <br>
      
      Absarita Y A, Spi
  </body>
</html>

 