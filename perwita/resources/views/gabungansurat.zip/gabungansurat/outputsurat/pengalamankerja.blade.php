<html>
  <head>
     
 


    <style type="text/css">

    .text-center{
      text-align:center;
    }


    </style>

  </head>

  <body>
      <div class="text-center">
        <h2>    <b>     <u>     To Whom It May Concern </u> </b> </h2>
             No : 35 / HRD / PT-PN / PPTKIS / I / 2017 </div>
      <br>
      <br>
      
      <b> I the Undersigned below, declare : </b>
      <br>
      <i> saya yang bertanda tangan dibawah ini, menyatakan</i>

    
      <p>
        Dengan ini menerangkan dengan sebenarnya : </p>
      
          <table border="0">
            <tr>
              <td width="20"> </td>
              <td width="50"> <b> Nama </b> </td>
              <td width="10"> <b> : </b> </td>
              <td width="200"> <b>FIKI HARTANTO </b></td>
            </tr>

            <tr>
              <td width="20"> </td>
              <td width="50"> <b> Place / Date of Birth </b> </td>
              <td width="10"> <b> : </b></td>
              <td width="200"> <b> Surabaya, Jan 17, 1978 </b></td>
            </tr>

            <tr>
              <td width="20"> </td>
              <td width="50"> <b> Address </b> </td>
              <td width="10"> <b>: </b></td>
              <td width="200"> <b> Jl Ikan Gurami 1/9-A RT/RW 01/06 Kel Perak Babat Kec Krembangan Kota Surabaya </b></td>
            </tr>

          </table>
        <br>
        <br>
        <b>
        She has employed by PT PERWITA NUSARAYA as an Administration Staff from
        </b> <br>
        <i> telah bekerja di PT Perwita Nusaraya sebagai Staff Administrasi sejak  </i>
        <br><br>
        <div class="text-center">
        <b> July 28, 2016 – December 1, 2016  </b> </div>
<br>
        <b> She has responsible and has excellent communication skills and can work independently </b> <br>
        <i> Yang bersangkutan mempunyai tanggungjawab dan mampu berkomunikasi dengan baik serta dapat bekerja secara mandiri </i> <br>
        <br>

        <b> This letter is our reference and could be used as it should be </b> <br>
        <i> Surat pengalaman kerja ini diberikan untuk dapat digunakan sebagaimana mestinya  </i>
<br>
<br>
<br>
<br>
<br>
<br>
<br>
      

       Sidoarjo, 12 Juni 2017
       <br>
       Sincerely,
       <br>
       <br>
       <br>
       <br>
       <br>
       <br>
      
       <b> <u> Absarita Y A, SPi </u> </b>
        <br> HRD Manager
  </body>
</html>

 