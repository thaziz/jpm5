<html>
  <head>
     
 


    <style type="text/css">

    .text-center{
      text-align:center;
    }


    </style>

  </head>

  <body>
      <div class="text-center">
        <h2>    <b>     <u>SURAT KETERANGAN </u> </b> </h2>
             Nomor : 066 / PT-AWKB / VI / 2017 </div>
      <br>
    
      <p>
        Dengan ini menerangkan dengan sebenarnya : </p>
      
          <table border="0">
            <tr>
              <td width="20"> </td>
              <td width="50"> Nama</td>
              <td width="10"> :</td>
              <td width="200"> <b>FIKI HARTANTO </b></td>
            </tr>

            <tr>
              <td width="20"> </td>
              <td width="50"> Tempat, Tanggal Lahir</td>
              <td width="10"> :</td>
              <td width="200"> Jombang, 2 Desember 1995</td>
            </tr>

            <tr>
              <td width="20"> </td>
              <td width="50"> Alamat </td>
              <td width="10"> :</td>
              <td width="200"> Kedunglumpang RT/RW 02/01 Ds Kedunglumpang Kec Mojoagung Kab Jombang</td>
            </tr>

          </table>
        <br>
        <br>
       Adalah Pekerja PT AMERTA WIDIYA KARYA BHAKTI yang ditempatkan  di PT KARUNIA ALAM SEGAR SURABAYA terhitung mulai bekerja pada tanggal 5 September 2014 sampai dengan 2 Maret 2017 dan selama bekerja menunjukkan dedikasi dan hasil kerja yang baik. 

       <br>
       <br>
       Demikian Surat Keterangan ini diberikan untuk dapat dipergunakan sebagaimana mestinya

       <br>
       <br>
       <br>
       <br>
      

       Sidoarjo, 12 Juni 2017
       <br>
       HRD
       <br>
       <br>
       <br>
       <br>
      
       Rifky Ardiansyah
  </body>
</html>

 