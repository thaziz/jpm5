<html>
  <head>
     
 


    <style type="text/css">

    .text-center{
      text-align:center;
    }


    </style>

  </head>

  <body>
      <div class="text-center">
        <h2>    <b>     <u>SURAT KETERANGAN </u> </b> </h2>
             Nomor : 066 / PT-AWKB / VI / 2017 </div>
      <br>
    
      <p>
       Dengan ini menerangkan dengan sebenarnya : </p>
      
          <table border="0">
          
            <tr>
              <td width="20"> </td>
              <td width="50"> Nama</td>
              <td width="10"> :</td>
              <td width="200"> <b> SIYADI </b></td>
            </tr>

            <tr>
              <td width="20"> </td>
              <td width="50"> Jabatan</td>
              <td width="10"> :</td>
              <td width="200">QC</td>
            </tr>

            <tr>
              <td width="20"> </td>
              <td width="50"> Alamat</td>
              <td width="10"> :</td>
              <td width="200">Ds Rowogempul RT/RW 06/08 Kec Lekok Kab Pasuruan</td>
            </tr>

          </table>
        <br>
        <br>
    Adalah Pekerja PT PERWITA NUSARAYA MJI yang ditempatkan di PT MASPION UNIT I Divisi ALUMINDO SHEET terhitung mulai bekerja pada tanggal 6 Maret 2010 sampai dengan 2 Februari 2016 dan selama bekerja menunjukkan dedikasi dan hasil kerja yang baik. 

       <br>
       <br>
      Demikian Surat Keterangan ini diberikan untuk dapat dipergunakan sebagaimana mestinya.

       <br>
       <br>
       <br>
       <br>
       <br>
       <br>
       <br>
       <br>

      Sidoarjo, 28 April 2016
       <br>
       Ass Manager Personalia
       <br>
       <br>
       <br>
       <br>
      
      Absarita Y A, Spi
  </body>
</html>

 