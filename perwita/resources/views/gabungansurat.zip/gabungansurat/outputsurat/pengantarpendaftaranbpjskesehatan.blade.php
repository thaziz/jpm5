<html>
  <head>
     
 


    <style type="text/css">

    .text-center{
      text-align:center;
    }


    </style>

  </head>

  <body>
     <table border="0">
      <tr>
        <td width="50"> Nomor</td>
        <td width="10"> :</td>
        <td width="200"> 277 / PT-PN / MJI / II / 2017 </td>
      </tr>
      
      <tr>
         <td width="50"> Lampiran </td>
         <td width="10"> :</td>
         <td width="200"> - </td>
      </tr>

      <tr>
         <td width="50"> Perihal </td>
         <td width="10"> :</td>
         <td width="200"> <b> <i> Surat Pengantar Pendaftaran Pendaftaran BPJS Kesehatan</i></b> </td>
      </tr>

      <tr>
        <td colspan="3"> </td>
      </tr>
      <tr>
        <td colspan="3"> </td>
      </tr>
      <tr>
        <td colspan="3"> </td>
      </tr>
      <tr>
        <td colspan="3"> </td>
      </tr>

      <tr>
        <td colspan="3"> </td>
      </tr>
      <tr>
        <td colspan="3"> </td>
      </tr><tr>
        <td colspan="3"> </td>
      </tr><tr>
        <td colspan="3"> </td>
      </tr>

      <tr>
        <td colspan="2">  </td>
        <td width="200"> Kepada</td>
      </tr>

      <tr>
        <td colspan="2">  </td>
        <td width="200"> YTH. BPJS Kesehatan KCP. Krian</td>
      </tr>

      <tr>
        <td colspan="2">  </td>
        <td width="200"> Jl. Gubernur Sunandar, Sidomulyo</td>
      </tr>

      <tr>
        <td colspan="2">  </td>
        <td width="200"> di Krian</td>
      </tr>

      <tr>
        <td colspan="3"> </td>
      </tr>
      <tr>
        <td colspan="3"> </td>
      </tr>
      <tr>
        <td colspan="3"> </td>
      </tr>
      <tr>
        <td colspan="3"> </td>
      </tr>
      <tr>
        <td colspan="3"> </td>
      </tr>

      <tr>
        <td colspan="2">  </td>
         <td width="200"> Dengan hormat,</td>
      </tr>

      <tr>
         <td colspan="2">  </td>
        <td colspan="200"> Dengan ini menerangkan bahwa Pekerja kami : </td>
      </tr>

  </table>

  <table>
    <tr>
      <td colspan="4">
    </tr>
    <tr>
          <td colspan="4">
    </tr>

    </tr>
        <tr>
        <td colspan="2"> </td>
        <td width="100"> </td>
        <td width="100"> Nama </td>
        <td width="20"> : </td>
        <td width="50"> <b> NAIRUL HAKIM </b>  </td>
      </tr>

      <tr>
        <td colspan="2"> </td>
        <td width="50"> </td>
        <td width="100"> No KPK </td>
        <td width="20"> : </td>
        <td width="50">  0001839482673  </td>
      </tr>

      <tr>
        <td colspan="2"> </td>
        <td width="50"> </td>
        <td width="100"> Alamat </td>
        <td width="20"> : </td>
        <td width="50">  Ds Lebanisuko RT/RW 08/02 Kec Wringinanom Kab Gresik  </td>
      </tr>
  </table>
   

    <table>

    <tr>
      <td colspan="4">
    </tr>
    <tr>
          <td colspan="4">
    </tr>
     <tr>
          <td colspan="4">
    </tr>
     <tr>
          <td colspan="4">
    </tr>
      <tr>
         <td width="50">  </td>
         <td width="10"> </td>
        <td colspan="200"> Adalah Pekerja borong PT PERWITA NUSARAYA MJI yang ditempatkan di PT ADYABUANA PERSADA kode BU (01950344) yang mana pekerja tersebut di atas mendaftarkan istri sebagai peserta BPJS Kesehatan yang penanggung tambahannya ditanggung oleh pekerja </td>
      </tr>

     <tr>
      <td colspan="4">
    </tr>
    <tr>
          <td colspan="4">
    </tr>
     <tr>
          <td colspan="4">
    </tr>
     <tr>
          <td colspan="4">
    </tr>

    <tr>
         <td width="50">  </td>
         <td width="10"> </td>
        <td colspan="200">Untuk itu kami mohon bantuannya agar Pekerja kami tersebut bisa diproses penambahan anggota keluarga inti sebagai peserta BPJS Kesehatan. </td>
      </tr>
      

       <tr>
         <td width="50">  </td>
         <td width="10"> </td>
        <td colspan="200">  Demikian Surat Pengantar dan permohonan kami, atas  perhatian dan kerjasamanya kami ucapkan terima kasih </td>
      </tr>
      
       <tr>
        <td colspan="4">
      </tr>
      <tr>
            <td colspan="4">
      </tr>
       <tr>
            <td colspan="4">
      </tr>
       <tr>
            <td colspan="4">
      </tr>

       <tr>
         <td width="50">  </td>
         <td width="10"> </td>
        <td colspan="200">  Sidoarjo, 18 Februari 2017   </td>
      </tr>



       <tr>
         <td width="50">  </td>
         <td width="10"> </td>
        <td colspan="200">    Manajer HRD   </td>
      </tr>  

     <tr>
        <td colspan="4">
      </tr>
      <tr>
            <td colspan="4">
      </tr>
      <tr>
            <td colspan="4">
      </tr>
      <tr>
            <td colspan="4">
      </tr>
      <tr>
            <td colspan="4">
      </tr>
      <tr>
            <td colspan="4">
      </tr> <tr>
            <td colspan="4">
      </tr> <tr>
            <td colspan="4">
      </tr> <tr>
            <td colspan="4">
      </tr> <tr>
            <td colspan="4">
      </tr> <tr>
            <td colspan="4">
      </tr> <tr>
            <td colspan="4">
      </tr> <tr>
            <td colspan="4">
      </tr><tr>
            <td colspan="4">
      </tr><tr>
            <td colspan="4">
      </tr>

    <tr>
         <td width="50">  </td>
         <td width="10"> </td>
        <td colspan="200">     Absarita Y A, SPi   </td>
      </tr> 




   


     </table> 
  </body>
</html>

 