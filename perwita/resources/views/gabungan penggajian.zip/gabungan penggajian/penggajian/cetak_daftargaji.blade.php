<html>
<head>
	<title>Cetak Pendaftaran BPJS</title>
	<style type="text/css">
table, th, td {
    border: 1px solid black;
    border-collapse: collapse;
}
th, td {
    padding: 5px;
    ;    
}
	</style>
	
</head>
<body>
<h3>DAFTAR GAJI KARYAWAN PT PERWITA NUSARAYA </br>BULAN </h3>
<table style="width:100%">
                     <tr>
                        <th>NO URUT</th>
                        <th>NAMA</th>
                        <th>NIK</th>
                        <th>JABATAN</th>
                        <th>GAJI POKOK</th>
                        <th>T. MASA KERJA</th>
                        <th>T. JABATAN</th>
                        <th>T. FUNGSIONAL</th>
                        <th>BPJS TK</th>
                        <th>POTONGAN</th>
                        <th>TOTAL</th>
                        <th>TTD</th>
                    </tr>
                      <tr>
                        <td align="center">1.</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>	
                        <td></td> </tr>
                        <tr>
                        <td align="center">2.</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>	
                        <td></td> </tr><tr>
                        <td align="center">3.</td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>
                        <td></td>	
                        <td></td> </tr>
</table>


</body>
</html>